import React, {Component} from 'react';

import LogInButton from "./LogInButton";
import LogOutButton from "./LogOutButton";

export default class LoginLogout extends Component {
    constructor(props) {
        super(props);
        // create a ref to store the textInput DOM element
        this.localstore = localStorage.getItem("userInfo");
    }
render() {
    if ( this.localstore===null ) {
        return (
        <LogInButton />
    )
    } else {
            const json = JSON.parse(this.localstore);
            if (json.user.success!==undefined && json.user.success)
                return  <LogOutButton />
            else
                return  <LogInButton />
    }

}
}