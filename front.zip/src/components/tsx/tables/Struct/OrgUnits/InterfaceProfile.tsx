export default interface Profile {
    id: string;
    name: string;
    user: { username: string } ;
  }