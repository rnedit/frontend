export interface NewOrgUnit {
    id : string | undefined;
    name: string | undefined;
 
}