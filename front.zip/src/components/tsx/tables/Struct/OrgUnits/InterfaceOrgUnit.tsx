export default interface OrgUnit {
    id: string;
    name: string;
    homeOrgUnit: boolean;
  }