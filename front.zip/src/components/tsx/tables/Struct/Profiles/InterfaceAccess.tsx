export interface interfaceACCESS {
    id:number,
    info:string,
    name:string,
}