export interface NewUserAU {
    username: string;
    firstName: string;
    lastName: string;
    email: string;
    
    roles: string;

    password: string;
}