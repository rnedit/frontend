export const ACCESS = [
   
    {id:0,name:"ACCESS_CREATEDOCUMENT",info:""},
   
    {id:1,name:"ACCESS_CREATEPROFILE",info:""},
    
    {id:2,name:"ACCESS_DELETEPROFILE",info:""},
    
    {id:3,name:"ACCESS_CREATEUSER",info:""},
    
    {id:4,name:"ACCESS_DELETEUSER",info:""},
    
    {id:5,name:"ACCESS_STRUCT",info:""},
    
    {id:6,name:"ACCESS_SPRAV",info:""},
    
    {id:7,name:"ACCESS_OUTDOC",info:""},
    
    {id:8,name:"ACCESS_INDOC",info:""},
    
    {id:9,name:"ACCESS_SZ",info:""},
   
    {id:10,name:"ACCESS_ORD",info:""},
    
    {id:11,name:"ACCESS_ALL",info:""}, //для админа
    
]
