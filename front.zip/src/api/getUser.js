import React from 'react';
import axios from "axios";

const getUser = (url, data) => {
    let post = '';
    let error1 = '';
    let isSignin = false;



        if (isSignin) {
            return (
                post
            )
        } else {
            return (
                error1
            )
        }

}

export default getUser;