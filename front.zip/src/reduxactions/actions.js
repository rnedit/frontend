export const updateCurrentUser = (data) => ({
    user:data,
    type: 'CURRENT_USER'
});

export const updateValueUser = (data) => ({
    user:data,
    type: 'CURRENT_USER_UPDATE'
});

