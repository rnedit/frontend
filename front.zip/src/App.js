import React, { Component } from 'react';
import {Router, Route, Switch} from 'react-router-dom';

import Error from './components/Error';
import TopAppBar from './components/TopAppBarAndLeftMenu';
import Login from './components/Login';

import {UserContext, UserProvider} from './context/UserContext'
import history from "./components/utils/history";

export const proxy = "http://localhost:8080"

class App extends Component {
    static contextType = UserContext
    constructor(props) {
        super(props);

        this.state = {
            isLoading: true,
        };
    };

  componentDidMount() {
    this.setState({isLoading: false });
  }

  render() {
    const { isLoading} = this.state;
    if (isLoading) {
      return <p>Loading...</p>;
    }

    return (

        <UserProvider >
            <Router history={history}>
              <Switch>

                <Route path="/login" component={Login}/>
                <Route
                    path='/'
                    component={TopAppBar}/>
                {/*
                            render={(props) => <TopAppBar {...props} user={this.state.user}/>}

                            />
*/}
                <Route component={Error}/>
              </Switch>
          </Router>
        </UserProvider>
    );
  }
}

export default App;