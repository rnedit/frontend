import React, {Component} from 'react';

import LogInButton from "./LogInButton";
import LogOutButton from "./LogOutButton";

export default class LoginLogout extends Component {
    constructor(props) {
        super(props);
        // create a ref to store the textInput DOM element
        this.localstore = localStorage.getItem("info");
    }
render() {
    if (this.localstore===undefined || this.localstore===null) {

        return (
                <LogInButton />
        )
    } else {
        return (
                <LogOutButton />
        )
    }

}
}