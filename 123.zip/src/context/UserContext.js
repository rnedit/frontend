import React, {Component, createContext} from 'react'

const UserContext = createContext({user:{username:'Гость',success:false}});

class UserProvider extends Component {
    // Context state
    constructor(props) {
        super(props);
        let userdata = '';
        let localstore = localStorage.getItem("info");
        if (
            localstore===undefined || localstore===null
        ) {
             userdata = {user:{username:'Гость',success:false}}
            localStorage.clear()
        } else {
             userdata = JSON.parse(localStorage.getItem("info"))
        }

        this.state =
        {
            setUser: this.setUser,
            user: userdata.user,
        }

    }
    componentDidUpdate(prevProps, prevState) {
        if (this.state.user !== prevState.value) {
            const user = {user:{
                    id:this.state.user.id,
                    username:this.state.user.username,
                    name:this.state.user.name,
                    success:this.state.user.success
                }

            }
            localStorage.setItem("info",JSON.stringify(user))
        }
    }
    // Method to update state
    setUser = (user) => {
        this.setState(prevState => ({ user }));
    }

    render() {
        const { children } = this.props
        const { user } = this.state
       // const { setUser } = this
        return (
            <UserContext.Provider
                value={{
                    user,
                    setUser: this.setUser,
                }}
            >
                {children}
            </UserContext.Provider>
        )
    }
}

export { UserProvider, UserContext }

