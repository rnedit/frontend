export interface NewOrgUnit {
   
    name: string | undefined;
 
}