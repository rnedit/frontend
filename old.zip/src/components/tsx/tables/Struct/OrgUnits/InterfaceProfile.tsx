export default interface Profile {
    id: string;
    name: string;
  }