export interface NewOrgUnits {
   
    name: string | undefined;

}